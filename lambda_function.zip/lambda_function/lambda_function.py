import boto3

def lambda_handler(event, context):
    iam_client = boto3.client('iam')

    # Get all IAM users
    users_response = iam_client.list_users()

    for user in users_response['Users']:
        username = user['UserName']

        # List access keys for the user
        keys_response = iam_client.list_access_keys(UserName=username)

        for key in keys_response['AccessKeyMetadata']:
            access_key_id = key['AccessKeyId']

            # Create new access key
            new_key_response = iam_client.create_access_key(UserName=username)
            new_access_key_id = new_key_response['AccessKey']['AccessKeyId']
            new_secret_access_key = new_key_response['AccessKey']['SecretAccessKey']

            # Update the Lambda function environment with the new key
            iam_client.update_access_key(UserName=username, AccessKeyId=access_key_id, Status='Inactive')

    return {
        'statusCode': 200,
        'body': 'Access keys rotated successfully.'
    }
