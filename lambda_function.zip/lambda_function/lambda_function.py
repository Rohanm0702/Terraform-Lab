import boto3
import logging

# Initialize AWS resources
ec2_client = boto3.client('ec2')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Get all EBS volumes in the region
        response = ec2_client.describe_volumes()
        
        for volume in response['Volumes']:
            volume_id = volume['VolumeId']
            logger.info(f"Taking snapshot of EBS volume {volume_id}")
            
            # Create snapshot
            snapshot_response = ec2_client.create_snapshot(
                VolumeId=volume_id,
                Description=f"Snapshot created by Lambda function at {event['time']}"
            )
            
            snapshot_id = snapshot_response['SnapshotId']
            logger.info(f"Snapshot {snapshot_id} created for volume {volume_id}")
            
    except Exception as e:
        logger.error(f"Error creating EBS snapshot: {str(e)}")
        raise e
